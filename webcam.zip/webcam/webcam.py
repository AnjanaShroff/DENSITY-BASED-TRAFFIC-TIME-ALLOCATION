import cv2
import schedule

cam = cv2.VideoCapture(0)
#cv2.namedWindow("Webcam")
img_counter = 1
def capture():
    global img_counter
    img_name = "capture_img_{}.png".format(img_counter)
    cv2.imwrite(img_name, frame)
    print("screenshot taken")
    img_counter += 1

schedule.every(5).seconds.do(capture)# Set up schedule before loop
while True:
    ret, frame = cam.read()
    if not ret:
        print("failed to grab frame")
        break
    cv2.imshow("test", frame)
    schedule.run_pending()
    k = cv2.waitKey(100)  # 1/10 sec delay; no need for separate sleep
    if k % 256 == 27:
        print("closing the WEBCAM")# ESC pressed
        break
cam.release()
cv2.destroyAllWindows()
